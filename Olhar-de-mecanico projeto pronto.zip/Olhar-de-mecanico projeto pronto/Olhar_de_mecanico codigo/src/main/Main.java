package main;
import java.lang.Thread;
import java.sql.SQLException;
import java.util.Scanner;
import classes.ConsoleColors;
import classes.DbContext;
import classes.Funcoes;


public class Main {
	
	public static void main(String[] args) throws InterruptedException, SQLException {
		boolean continuar = true;
		Scanner input = new Scanner(System.in);
		DbContext db = new DbContext();
		while (continuar) {
			Funcoes.mostrarMenu();
			int opcao = Funcoes.leropcao(input);
			System.out.println("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
			if (opcao == 1) {
				Funcoes.linha();
				Progopcao1.progopcao1(input, db);
				System.out.println("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
			} 
			else if (opcao == 2) {
				Funcoes.linha();
				ProgAcessobanco.progacessobanco(input, db);
				System.out.println("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
			} 
			else if (opcao == 3) {
				Funcoes.linha();
				System.out.println("Encerrando... Ate Logo :)");
				System.out.println("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
				continuar = false;
			} 
			else {
				
				System.out.println(ConsoleColors.RED_BACKGROUND +"Alternativa invalida. Tente novamente."+ ConsoleColors.RESET);
				Thread.sleep(1000);
			}
		}
		input.close();
		System.out.println("Finalizado sem erro.");
	}
}