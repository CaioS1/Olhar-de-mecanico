package main;
import java.sql.SQLException;
import java.util.Scanner;
import classes.Acessobanco;
import classes.DbContext;
import classes.Funcoes;

public class Progopcao1 {
	
	public static void progopcao1(Scanner input, DbContext db) throws InterruptedException, SQLException {
		
		boolean continuar = true;
		
		while (continuar) {
			
			Funcoes.mnprog1();
			int opcao = Funcoes.leropcao(input);
			
			if (opcao == 1) {
				// funcao de pesuisa no banco
				Acessobanco.pesquisar(input, db);
				System.out.println("APERTE ENTER PARA CONTINUAR :)");
				input.nextLine();
				System.out.println("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
			}
			
			else if (opcao == 2) {
				// funcao de comparar modelos
				Acessobanco.compararModelos(input, db);
				System.out.println("APERTE ENTER PARA CONTINUAR :)");
				input.nextLine();
				System.out.println("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
			}
			
			else if(opcao ==3) {
				// lista todos os dados presentes no banco
				Acessobanco.listarTudo(db);
				System.out.println("APERTE ENTER PARA CONTINUAR :)");
				input.nextLine();
				System.out.println("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
			}
			
			else if (opcao == 4) {
				// volta ao menu principal
				System.out.println("Voltando ao menu principal");
				Funcoes.linha();
				Funcoes.dormir(500);
				continuar = false;
				System.out.println("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
			}
			
			else {
				// Vem pra ca para opcao invalida.
				Funcoes.msgnErro("Opção inválida. Tente novamente");
				Funcoes.dormir(800);
				System.out.println("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
				
			}
		}
	}
}
