package main;
import classes.Acessobanco;
import classes.ConsoleColors;
import classes.DbContext;
import classes.Funcoes;

import java.sql.SQLException;
import java.util.Scanner;

public class ProgAcessobanco {
	//programa para interacao com o banco de dados
	public static void progacessobanco(Scanner input, DbContext db) throws InterruptedException, SQLException {
		boolean continuar = true;
		while (continuar) {
			
			Funcoes.linha();
			Funcoes.menu_acessoBanco();
			int opcao = Funcoes.leropcao(input);
			
			if (opcao == 1) {
				// inserir item no banco
				Acessobanco.inserirNovo(input, db);
				System.out.println("APERTE ENTER PARA CONTINUAR :)");
				input.nextLine();
				System.out.println("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");;
			}
			else if(opcao == 2) {
				// pesquisar item no banco
				Acessobanco.pesquisar(input, db);
				System.out.println("APERTE ENTER PARA CONTINUAR :)");
				input.nextLine();
				System.out.println("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
			}
			else if (opcao == 3) {
				// atualizar item do banco
				Acessobanco.update(input, db);
				System.out.println("APERTE ENTER PARA CONTINUAR :)");
				input.nextLine();
				System.out.println("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
			}
			else if (opcao == 4) {
				// listar tudo do banco
				Acessobanco.listarTudo(db);
				System.out.println("APERTE ENTER PARA CONTINUAR :)");
				input.nextLine();
				System.out.println("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
				
			}
			else if (opcao == 5) {
				// Deletar item no banco
				Acessobanco.deletar(input, db);
				System.out.println("APERTE ENTER PARA CONTINUAR :)");
				input.nextLine();
				System.out.println("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
			}
			else if (opcao == 6) {
				// voltar ao menu principal
				System.out.println("Voltando ao menu principal");
				Funcoes.dormir(1000);
				continuar = false;
			}
			else {
				System.out.println(ConsoleColors.RED_BACKGROUND + "Opcao invalida" + ConsoleColors.RESET);
				System.out.println("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
			}
		}
	}
}