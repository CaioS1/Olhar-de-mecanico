/**
 * 
 */
/**
 * 
 */
module Olhar_de_mecanico {
	requires java.sql;
}