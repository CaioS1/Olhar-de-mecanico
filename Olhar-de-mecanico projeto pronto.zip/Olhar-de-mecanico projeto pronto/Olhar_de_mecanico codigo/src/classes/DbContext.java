package classes;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.DriverManager;

public class DbContext {
	
	private String url = "jdbc:postgresql://localhost:5432/Olhar_de_mecanico";
	private String usuario = "postgres";
	private String senha = "olhardemecanico";
	
	public Connection conection = null;
	
	public DbContext() {}
	
	// funcao de conexao do banco de dados
	public void conectBanco() {
		
		//System.out.println(ConsoleColors.GREEN_BOLD + "\n ----- Conectando Banco de dados... ----- " + ConsoleColors.RESET);
		try {
			this.conection = DriverManager.getConnection(url, usuario, senha);
			//System.out.println(ConsoleColors.GREEN_BOLD_BRIGHT + " ----- Conexao bem sucedida ----- \n" + ConsoleColors.RESET);
		} 
		catch(Exception e) {
			Funcoes.msgnErro("Falha na conexao. Erro: " + e.getMessage());
		}
	}
	
	// funcao de desconexao com o banco
	public void desconectBanco() {
	
		//System.out.println(ConsoleColors.GREEN_BRIGHT + " \n ----- Desconectando banco... ----- " + ConsoleColors.RESET);
		try {
			if (this.conection != null && !this.conection.isClosed()) {
                this.conection.close();
                //System.out.println(ConsoleColors.GREEN_BOLD_BRIGHT + " ----- Banco desconectado com sucesso ----- \n" + ConsoleColors.RESET);
			}
		} 
		catch (Exception e){
			Funcoes.msgnErro("Erro ao fechar o banco." + e.getMessage());
		}
	}
	
	// funcao de execucao da query que retorna um resultado do banco
	public ResultSet execQuerySql(String query) {
		try {
			Statement stmt = this.conection.createStatement();
			ResultSet resultset = stmt.executeQuery(query);
			return resultset;
		}
		catch (Exception e) {
			Funcoes.msgnErro("Erro ao executar query: " + e.getMessage());
			return null;
		}
	}
	
	// executa de quaery para update sem retorno 
	public boolean execUpdateSql(String query) {
	    Statement stmt = null;
	    try {
	        stmt = this.conection.createStatement();
	        stmt.executeUpdate(query);
	        return true;
	    } catch (Exception e) {
	        Funcoes.msgnErro("Erro inesperado ao executar update: " + e.getMessage());
	        return false;
	    } finally {
	        if (stmt != null) {
	            try {
	                stmt.close();
	            } catch (Exception e) {
	                Funcoes.msgnErro("Erro ao fechar o Statement." + e.getMessage());
	            }
	        }
	    }
	}
}