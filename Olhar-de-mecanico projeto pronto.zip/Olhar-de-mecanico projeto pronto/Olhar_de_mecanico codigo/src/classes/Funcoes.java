package classes;
import java.util.Scanner;
import java.lang.Thread;

public class Funcoes {
	
	// Menu principal
	public static void mostrarMenu() {
		System.out.println( ConsoleColors.BLUE + "-----------------------------------------------------------");
		System.out.println(ConsoleColors.GREEN + "                 \\   Olhar de Mecânico   /                ");
		System.out.print(   ConsoleColors.BLUE + "-----------------------------------------------------------\n" +
					  ConsoleColors.WHITE_BOLD + "Menu principal do sistema de busca de veículos.\n"+
					  							 "Neste menu escolhendo a opcao 1 você pode acessar o programa\n"+
					  							 "com as funções para pesquisar modelos, comparar modelos e \n"+
					  							 "listar todos os carros registrados no banco. \n"+
					  							 "E acessar o banco de dados do sistema integrado na opção 2, \n"+
					  							 "você pode interagir com o sistema, podendo inserir novo carro,\n" +
					  							 "pesquisar um carro no sistema, atualizar um carro existente,\n"+
					  							 "listar todos os registros do sistema de carros e pode deletar\n"+
					  							 "um registro existente no sistema\n"
			  + ConsoleColors.BLUE_BOLD_BRIGHT + "Digite o numero da opcao desejada:\n"
					     + ConsoleColors.RESET + " [1] " + ConsoleColors.YELLOW_BOLD + "Acessar programa\n"
					     + ConsoleColors.RESET + " [2] " + ConsoleColors.GREEN_BOLD + "Acessar armazenamento do sistema\n"
					     + ConsoleColors.RESET + " [3] " + ConsoleColors.RED_UNDERLINED +"Sair\n" 
					     + ConsoleColors.RESET + "Opção: ");
	}
	
	// menu de pesquisa no Acesso ao banco na funcao pesquisar
	public static void menu_pesq() {
		System.out.println(ConsoleColors.BLUE + "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=\n");
		System.out.println(ConsoleColors.GREEN + "             Menu de pesquisa              \n");
		System.out.println(ConsoleColors.BLUE + "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=\n" + ConsoleColors.RESET);
		System.out.print(						"Escolha a opção da característica que deseja\n"+
												"usar para a pesquisar no banco.\n"
						+ ConsoleColors.RESET + " [1]  " + ConsoleColors.YELLOW + "ID\n"
						+ ConsoleColors.RESET + " [2]  " + ConsoleColors.YELLOW + "Modelo\n"
						+ ConsoleColors.RESET + " [3]  " + ConsoleColors.YELLOW + "Marca\n" 
						+ ConsoleColors.RESET + " [4]  " + ConsoleColors.YELLOW + "Preço Medio\n" 
						+ ConsoleColors.RESET + " [5]  " + ConsoleColors.YELLOW + "Custo medio de manutenção\n"
						+ ConsoleColors.RESET + " [6]  " + ConsoleColors.YELLOW + "Consumo(km/l)\n" 
						+ ConsoleColors.RESET + " [7]  " + ConsoleColors.YELLOW + "Relação peso-potência\n"
						+ ConsoleColors.RESET + " [8]  " + ConsoleColors.YELLOW + "Motorizacao(combustão, híbrido ou elétrico)\n" 
						+ ConsoleColors.RESET + " [9]  " + ConsoleColors.YELLOW + "Torque\n"
						+ ConsoleColors.RESET + " [10] " + ConsoleColors.YELLOW + "Tipo(sedã, coupé, esportivo, ...)\n" 
						+ ConsoleColors.RESET + " [11] " + ConsoleColors.YELLOW + "Cilindrada do motor\n" 
						+ ConsoleColors.RESET + " [12] " + ConsoleColors.YELLOW + "Câmbio\n"
						+ ConsoleColors.RESET + " [13] " + ConsoleColors.RED_UNDERLINED + "Cancelar\n"
						+ ConsoleColors.RESET + "Opcao: " + ConsoleColors.RESET);
	}
	
	// menu da opcao 1 do menu principal
	public static void mnprog1() {
		System.out.print(ConsoleColors.BLUE_BOLD +"----------------------------------------\n" + 
							   ConsoleColors.GREEN +"  Menu de funcionalidades do sistema\n" + 
							   						"             Bem vindo\n" + 
						   ConsoleColors.BLUE_BOLD +"----------------------------------------\n" +ConsoleColors.RESET+
							   						"Aqui você pode pesquisar modelos disponiveis\n"+
							   						"no banco selecionando a opção 1, comparar \n"+
							   						"dois modelos desejados selecionando a opção 2\n"+
							   						"e selecionando a opção três você pode listar"+
							   						"todos os registros disponiveis\n"+
				   ConsoleColors.BLUE_BOLD_BRIGHT + "Escolha a opção desejada:\n" + ConsoleColors.RESET +
					   								" [1] " + ConsoleColors.PURPLE_BRIGHT + "Pesquisar modelos\n" + ConsoleColors.RESET + 
					   								" [2] " + ConsoleColors.YELLOW +  "Comparar modelos\n" + ConsoleColors.RESET +
					   								" [3] " + ConsoleColors.GREEN + "Listar disponíveis\n" + ConsoleColors.RESET +
					   								" [4] " + ConsoleColors.RED_UNDERLINED + "Voltar ao Menu Inicial\n" + ConsoleColors.RESET + "Opção: " );
	}
	
	// funcao de leitura com tratamento de formato invalido
	public static int leropcao(Scanner input) {
		int opcao = 0;
		try{
			opcao = Integer.parseInt(input.nextLine());
		} 
		catch (NumberFormatException e) {
			System.out.println(ConsoleColors.RED_UNDERLINED + "Formato invalido" + ConsoleColors.RESET);
			opcao = 0;
		}
		return opcao;
	}
	
	//  menu do programa de acesso ao banco
	public static void menu_acessoBanco() {
		System.out.print(  ConsoleColors.BLUE_BOLD + "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=\n" + 
						   ConsoleColors.GREEN_BOLD +"         Acesso ao Banco de Dados         \n" + 
						   ConsoleColors.BLUE +      "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=\n" + ConsoleColors.RESET+
						   							 "Programa que interage com o banco de dados\n"+
						   							 "aqui você excutando a ação desejada poderá\n"+
						   							 "inserir novo carro no registro, pesquisar no\n"+
						   							 "banco um carro com uma caracteristica\n"+
						   							 "desejada, atualizar o regsitro do carro\n"+
						   							 "desejado, listar carros disponiveis \n"+
						   							 "registrados e a opção deletar que deleta\n"+
						   							 "um registro do banco usando o ID do resgistro\n"+
						   							 "no banco.\n"+
						  ConsoleColors.BLUE_BRIGHT +"Digite o numero da acao desejada no banco:\n"
						     + ConsoleColors.RESET + " [1] " + ConsoleColors.BLUE_BOLD + "Inserir novo carro\n" 
						     + ConsoleColors.RESET + " [2] " + ConsoleColors.YELLOW_BOLD + "Pesquisar carro\n" 
						     + ConsoleColors.RESET + " [3] " + ConsoleColors.PURPLE_BOLD + "Atualizar registro de carro\n" 
						     + ConsoleColors.RESET + " [4] " + ConsoleColors.GREEN_BOLD + "Listar carros registrados\n" 
						     + ConsoleColors.RESET + " [5] " + ConsoleColors.RED_BOLD + "Deletar carro\n" 
						     + ConsoleColors.RESET + " [6] " + ConsoleColors.RED_UNDERLINED + "Voltar ao menu principal\n"
						     + ConsoleColors.RESET + "Opção: ");
	}
	
	// funcao de sleep
	public static void dormir(int t) throws InterruptedException {
		Thread.sleep(t); // tempo em milissegundos
	}
	
	// imprime uma linha para divisao no console 
	public static void linha() {
			System.out.println("===========================================================================================================");
	}
	
	// mensagem de erro personalizada
	public static void msgnErro(String txt) {
		linha();
		System.out.println(ConsoleColors.RED_UNDERLINED + "--  " + txt + "  --" + ConsoleColors.RESET);
		linha();
		System.out.println("\n");
	}
	
	// leitura de inteiro com validação
	public static int lerInteiro(Scanner input, String cor, String txt) {
		
		if (cor.isEmpty()) {
	        cor = ConsoleColors.RESET;
		}
		boolean valido = false;
		int n = 0;
		
		while (!valido) {
			
			try {
				System.out.print(cor + txt + ConsoleColors.RESET);
				n = input.nextInt();
				valido = true;
			}
			catch (Exception e) {
				input.next();
				msgnErro("Entrada inválida. Tente novamente");
			}
			input.nextLine();
		}
		return n;
	}
}