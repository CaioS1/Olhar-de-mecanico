package classes;

public class veiculo {
	String marca; // marca do veiculo
	String modelo; // modelo do veiculo
	int peso; // peso do veiculo
	double torque; // torque do veiculo
	String tipo; // ex : suv, seda, coupe, esportivo, etc
	String tracao; // tracao do veiculo
	short cavalos; // cavalos de potencia
	//double relacao_pp; // relacao peso potencia
	//String prob_freq; // problemas frequentes
	//boolean vidro_e; // vidro eletrico
	//byte aro_rodas; // aro das rodas
	//String farol; // ex: farol de led com farol de neblina
	String motorizacao; // combustao, hibrido ou eletrico
	//short ano_lanc; // ano de lancamento
	//double largura_v; // largura do veiculo
	//double comprimento_v; // comprimento do veiculo
	//double altura; // altura do veiculo
	double consumo_kmpl; // consumo de combustivel em km por litro
	//byte n_lugares; // numero de lugares do veiculo
	//short espaco_pm; // espaco do porta mala do veiculo
	//String tp_direcao; // tipo da direcao ex: direcao hidraulica, direcao eletrica
	String motor; // motor do veiculo
	String cambio; // cambio do veiculo
	//double nota_seg; // nota de seguranca do veiculo
	//String opiniao_mec; // opiniao dos mecanicos sobre o veiculo
	int preco_med; // preco medio do veiculo
	
	public String getMarca() {
		return marca;
	}
	public void setMarca(String marca) {
		this.marca = marca;
	}
	
	public String getModelo() {
		return modelo;
	}
	public void setModelo(String modelo) {
		this.modelo = modelo;
	}
	
	public String getMotor() {
		return motor;
	}
	public void setMotor(String motor) {
		this.motor = motor;
	}
	
	public int getPeso() {
		return peso;
	}
	public void setPeso(int peso) {
		this.peso = peso;
	}
	
	public String getMotorizacao() {
		return motorizacao;
	}
	public void setMotorizacao(String motorizacao) {
		this.motorizacao = motorizacao;
	}
	
	public String getTipo() {
		return tipo;
	}
	public void setTipo(String tipo) {
		this.tipo = tipo;
	}
	
	public int getPreco_med() {
		return preco_med;
	}
	public void setPreco_med(int preco_med) {
		this.preco_med = preco_med;
	}
	
	public double getTorque() {
		return torque;
	}
	public void setTorque(double torque) {
		this.torque = torque;
	}
	
	public String getTracao() {
		return tracao;
	}
	public void setTracao(String tracao) {
		this.tracao = tracao;
	}
	
	public String getCambio() {
		return cambio;
	}
	public void setCambio(String cambio) {
		this.cambio = cambio;
	}
	
	public double getConsumo_kmpl() {
		return consumo_kmpl;
	}
	public void setConsumo_kmpl(double consumo_kmpl) {
		this.consumo_kmpl = consumo_kmpl;
	}
	
	public short getCavalos() {
		return cavalos;
	}
	public void setCavalos(short cavalos) {
		this.cavalos = cavalos;
	}
}
