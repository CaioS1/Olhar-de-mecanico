package classes;
import java.util.Locale;
import java.util.Scanner;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


public class Acessobanco {
	
	// funcao de pesquisa no banco
	
	public static void pesquisar(Scanner input, DbContext db) throws SQLException {
		
	    String query = "";
	    String resposta_coluna = "";
	    String resp_string = "";
	    float resp_float = 0.0f;
	    int resp_int = 0;
	    boolean condicao = true;

	    if (verificarDBvazio(db)) {
	    	return;
	    }
	        while (condicao) {
	            Funcoes.linha();
	            Funcoes.menu_pesq();
	            int opcao = Funcoes.leropcao(input);
	            
	            switch (opcao) {
	                case 1:
	                    resposta_coluna = "id";
	                    resp_int = Funcoes.lerInteiro(input, ConsoleColors.BLUE_BOLD, "Informe o ID do veiculo para pesquisa: ");                
	                    condicao = false;
	                    break;
	                case 2:
	                    resposta_coluna = "modelo";
	                    System.out.println(ConsoleColors.BLUE_BOLD + "Informe o MODELO do veiculo para pesquisa: " + ConsoleColors.RESET);
	                    resp_string = input.nextLine();
	                    condicao = false;
	                    break;
	                case 3:
	                    resposta_coluna = "marca";
	                    System.out.println(ConsoleColors.BLUE_BOLD + "Informe o MARCA do veiculo para pesquisa: " + ConsoleColors.RESET);
	                    resp_string = input.nextLine();
	                    condicao = false;
	                    break;
	                case 4:
	                    resposta_coluna = "preco_medio";
	                    resp_int = Funcoes.lerInteiro(input, ConsoleColors.BLUE_BOLD, "Informe o PREÇO MEDIO do veiculo para pesquisa \nNo formato: '123456...' sem virgula/ponto:\n");
	                    condicao = false;
	                    break;
	                case 5:
	                    resposta_coluna = "custo_med_manu";
	                    resp_int = Funcoes.lerInteiro(input, ConsoleColors.BLUE_BOLD, "Informe o CUSTO MEDIO DE MANUTENÇÃO do veiculo para pesquisa: \nNo formato: '123456...' sem virgula/ponto: \n");
	                    condicao = false;
	                    break;
	                case 6:
	                    resposta_coluna = "km_por_l";
	                    resp_int = Funcoes.lerInteiro(input, ConsoleColors.BLUE_BOLD, "Informe o CONSUMO(em km/l) do veiculo para pesquisa\nNo formato '10', '11':");
	                    condicao = false;
	                    break;
	                case 7:
	                    resposta_coluna = "relacao_pp";
	                    System.out.println(ConsoleColors.BLUE_BOLD + "Informe o RELAÇÃO PESO-POTÊNCIA do veiculo para pesquisa\n No formato '0,6','1,4', etc: " + ConsoleColors.RESET);
						resp_float = input.nextFloat();
						input.nextLine();
	                    condicao = false;
	                    break;
	                case 8:
	                    resposta_coluna = "motorizacao";
	                    System.out.println(ConsoleColors.BLUE_BOLD + "Informe o MOTORIZAÇÃO do veiculo para pesquisa\nNo formato 'combustao','hibrido','eletrico: " + ConsoleColors.RESET);
	                    resp_string = input.nextLine();
	                    condicao = false;
	                    break;
	                case 9:
	                    resposta_coluna = "torque";
	                    resp_int = Funcoes.lerInteiro(input, ConsoleColors.BLUE_BOLD, "Informe o TORQUE do veiculo para pesquisa\nNo formato '123...':");
	                    condicao = false;
	                    break;
	                case 10:
	                    resposta_coluna = "categoria";
	                    System.out.println(ConsoleColors.BLUE_BOLD + "Informe a CATEGORIA(suv, coupe, sedã, esportivo, ...) do veiculo para pesquisa: " + ConsoleColors.RESET);
	                    resp_string = input.nextLine();
	                    condicao = false;
	                    break;
	                case 11:
	                    resposta_coluna = "motor";
	                    System.out.println(ConsoleColors.BLUE_BOLD + "Informe a cilindrada do MOTOR do veiculo para pesquisa.\nSe o motor e 1,0 ; 2,0 ; etc.\nNo formato '1,0', '2,0': " + ConsoleColors.RESET);
						resp_float = input.nextFloat();
						input.nextLine();
	                    condicao = false;
	                    break;
	                case 12:
	                    resposta_coluna = "cambio";
	                    System.out.println(ConsoleColors.BLUE_BOLD + "Informe o CÂMBIO do veiculo para pesquisa(manual ou automático): " + ConsoleColors.RESET);
	                    resp_string = input.nextLine();
	                    condicao = false;
	                    break;
	                case 13:
	                    System.out.println(ConsoleColors.RED_BOLD_BRIGHT + " -- Pesquisa cancelada pelo usuário -- " + ConsoleColors.RESET);
	                    condicao = false;
	                    return;
	                default:
	                    Funcoes.msgnErro("Opcao inválida. Tente novamente.");
	            }
	        }

	        query = "SELECT * FROM public.veiculos WHERE " + resposta_coluna + " = ?";
	        try {
	            db.conectBanco();
	            PreparedStatement ps = db.conection.prepareStatement(query);
	            if (resposta_coluna.equals("relacao_pp") || resposta_coluna.equals("motor")) {
	                ps.setFloat(1, resp_float);
	            } else if (resposta_coluna.equals("id") || resposta_coluna.equals("preco_medio") || resposta_coluna.equals("custo_med_manu") || resposta_coluna.equals("torque")||
	            		resposta_coluna.equals("km_por_l")) {
	                ps.setInt(1, resp_int);
	            } else {
	                ps.setString(1, resp_string);
	            }
	            ResultSet rs = ps.executeQuery();

	            if (rs.next()) {
	            	Funcoes.linha();
	                System.out.println(ConsoleColors.BLUE_BRIGHT+"Veículo encontrado: "+ConsoleColors.WHITE_UNDERLINED + rs.getString("modelo")+ConsoleColors.RESET);
	                Funcoes.linha();
	            }
	            else {
	            	Funcoes.msgnErro("Veículo não encontrado");
	            }

	            ps.close();
	        } catch (Exception e) {
	            Funcoes.msgnErro("Erro ao executar pesquisa: " + e.getMessage());
	        } finally {
	            db.desconectBanco();
	        }
	}


	
	// inserir novo item no banco
	public static void inserirNovo(Scanner input, DbContext db) {
	        
        Locale.getDefault(); // importa do sistema a formataçao de numero de acordo com local
        Funcoes.linha();
        System.out.println(ConsoleColors.GREEN_BRIGHT + " -- Inserindo novo veículo --" + ConsoleColors.RESET);
        
        System.out.println(ConsoleColors.BLUE_BOLD + "Informe o MODELO do veiculo para inserir no banco: " + ConsoleColors.RESET);
        String modelo = input.nextLine();
        
        System.out.println(ConsoleColors.BLUE_BOLD + "Informe o MARCA do veiculo para inserir no banco: " + ConsoleColors.RESET);
        String marca = input.nextLine();
        
        int preco_med = Funcoes.lerInteiro(input, ConsoleColors.BLUE_BOLD, "Informe o PREÇO MEDIO do veiculo para inserir no banco\nNo formato: '123456...' sem virgula/ponto:\n");
        
        int custo_med_manu = Funcoes.lerInteiro(input, ConsoleColors.BLUE_BOLD, "Informe o CUSTO MEDIO DE MANUTENÇÃO do veiculo para inserir no banco\nNo formato: '123456...' sem virgula/ponto:\n");
        
        System.out.println(ConsoleColors.BLUE_BOLD + "Informe o CONSUMO(em km/l) do veiculo para inserir no banco\nNo formato '10', '11': \n" + ConsoleColors.RESET);
        float km_por_l = input.nextFloat();
        input.nextLine();
        
        System.out.println(ConsoleColors.BLUE_BOLD + "Informe o RELAÇÃO PESO-POTÊNCIA do veiculo para inserir no banco\n No formato '0,6','1,4': " + ConsoleColors.RESET);
        float relacao_pp = input.nextFloat();
        input.nextLine();
        
        System.out.println(ConsoleColors.BLUE_BOLD + "Informe o MOTORIZAÇÃO do veiculo para inserir no banco\nNo formato 'combustao','hibrido','eletrico: " + ConsoleColors.RESET);
        String motorizacao = input.nextLine();
       		 
        int torque = Funcoes.lerInteiro(input, ConsoleColors.BLUE_BOLD, "Informe o TORQUE do veiculo para inserir no banco\nNo formato '123...': \n");
        
        System.out.println(ConsoleColors.BLUE_BOLD + "Informe a CATEGORIA(suv, coupe, sedã, esportivo, ...) do veiculo para inserir no banco: " + ConsoleColors.RESET);
        String categoria = input.nextLine();
        
        System.out.println(ConsoleColors.BLUE_BOLD + "Informe a CILINDRADA do MOTOR do veiculo para inserir no banco\nSe o motor e 1,0 ; 2,0 ; etc.\nNo formato '1,0', '2,0': " + ConsoleColors.RESET);
        String motor = input.nextLine();
        
        System.out.println(ConsoleColors.BLUE_BOLD + "Informe o CÂMBIO do veiculo para inserir no banco(manual ou automático): " + ConsoleColors.RESET);
        String cambio = input.nextLine();

        try {
	        db.conectBanco();
	        String query = "INSERT INTO public.veiculos (modelo, marca, preco_medio, custo_med_manu, km_por_l, relacao_pp, motorizacao, torque, categoria, motor, cambio) " +
	                       "VALUES (?,?,?,?,?,?,?,?,?,?,?)";	        
	        PreparedStatement ps = db.conection.prepareStatement(query); // preparacao para query
			ps.setString(1, modelo);
			ps.setString(2, marca);
			ps.setInt(3, preco_med);
			ps.setInt(4, custo_med_manu);
			ps.setFloat(5, km_por_l);
			ps.setFloat(6, relacao_pp);
			ps.setString(7, motorizacao);
			ps.setInt(8, torque);
			ps.setString(9, categoria);
			ps.setString(10, motor);
			ps.setString(11, cambio);
			ps.executeUpdate(); // executa a quaery desejada
	        System.out.println(ConsoleColors.GREEN_BOLD_BRIGHT + "----- Novo veículo cadastrado com sucesso! -----\n" + ConsoleColors.RESET);    
        }
        catch (Exception e) {
        	Funcoes.msgnErro("Erro ao inserir: "+ e.getMessage());
        }
        finally { 
        	db.desconectBanco();
        }
    }
	
	// deletar item no banco de dados
	public static void deletar(Scanner input, DbContext db) throws SQLException {

		if(verificarDBvazio(db)) {
			System.out.println(ConsoleColors.RED_BOLD + "Banco de dados vazio. Não há veículos para deletar." + ConsoleColors.RESET);
			return;
		}
		int id_veiculo = Funcoes.lerInteiro(input, ConsoleColors.BLUE_BRIGHT, "Informe o ID do veículo a ser deletado [Digite '0' para cancelar]: ");
		if (id_veiculo == 0) {
	        System.out.println(ConsoleColors.YELLOW_BOLD + "Operação cancelada pelo usuário." + ConsoleColors.RESET);
	        return;
	    }
		System.out.println("verificando id");
		if (verificarID(db, id_veiculo)) {
	        System.out.println(ConsoleColors.GREEN_BRIGHT + "ID válido." + ConsoleColors.RESET);
	    } else {
	        System.out.println(ConsoleColors.RED_BOLD + "ID inválido." + ConsoleColors.RESET);
	        return;
	    }
		try {
	        db.conectBanco();
	        String query = "DELETE FROM public.veiculos WHERE id = ?";
	        PreparedStatement ps = db.conection.prepareStatement(query);
	        ps.setInt(1, id_veiculo);
	        ps.executeUpdate();
	        System.out.println(ConsoleColors.GREEN_BOLD_BRIGHT+"-- Veículo deletado com sucesso --"+ConsoleColors.RESET);
	        
	    } catch (Exception e) {
	        Funcoes.msgnErro("Erro ao deletar: " + e.getMessage());
	    } finally {
	        db.desconectBanco();
	    }
	}
	
	
	// executar update de item no banco
	public static void update(Scanner input, DbContext db) throws SQLException {
		
		//System.out.println("verificando banco");
		if(verificarDBvazio(db)) {
			System.out.println(ConsoleColors.RED_BOLD + "---- O banco não possui dados ----\n" + ConsoleColors.RESET);
			return;
		}
		int id = Funcoes.lerInteiro(input, ConsoleColors.BLUE_BOLD_BRIGHT, "Insira o ID do veiculo a ser atualizado: ");
		//System.out.println("verificando id");
		if (verificarID(db, id)) {
			System.out.println("ID valido");
			}
		else {
			System.out.println("ID invalido");
			return;
		}
			
        System.out.println(ConsoleColors.BLUE_BOLD + "Informe o MODELO do veiculo para atualizar no sistema: " + ConsoleColors.RESET);
        String att_modelo = input.nextLine();

        System.out.println(ConsoleColors.BLUE_BOLD + "Informe o MARCA do veiculo para atualizar no sistema: " + ConsoleColors.RESET);
        String att_marca = input.nextLine();

        int att_precoMed = Funcoes.lerInteiro(input, ConsoleColors.BLUE_BOLD, "Informe o PREÇO MEDIO do veiculo para atualizar no sistema\nNo formato: '123456...' sem virgula/ponto:\n");

        int att_custo_med_manu = Funcoes.lerInteiro(input, ConsoleColors.BLUE_BOLD, "Informe o CUSTO MEDIO DE MANUTENÇÃO do veiculo para atualizar no sistema\nNo formato: '123456...' sem virgula/ponto: \n");

        System.out.println(ConsoleColors.BLUE_BOLD + "Informe o CONSUMO(km/l) do veiculo para atualizar no sistema\nNo formato '12...' sem virgula/ponto: " + ConsoleColors.RESET);
        float att_km_por_litro = input.nextFloat();
        input.nextLine();
        
        System.out.println(ConsoleColors.BLUE_BOLD + "Informe o RELAÇÃO PESO-POTÊNCIA do veiculo para atualizar no sistema\n No formato '0,6','1,4': " + ConsoleColors.RESET);
        float att_relacao_pp = input.nextFloat();
        input.nextLine();

        System.out.println(ConsoleColors.BLUE_BOLD + "Informe o MOTORIZAÇÃO do veiculo para atualizar no sistema\nNo formato 'combustao', 'hibrido' ou 'eletrico: " + ConsoleColors.RESET);
        String att_motorizacao = input.nextLine();

        System.out.println(ConsoleColors.BLUE_BOLD + "Informe o TORQUE do veiculo para atualizar no sistema\nNo formato '123...': \n" + ConsoleColors.RESET);
        float att_torque = input.nextFloat();
        input.nextLine();

        System.out.println(ConsoleColors.BLUE_BOLD + "Informe a CATEGORIA(suv, coupe, sedã, esportivo, ...) do veiculo para atualizar no sistema:" + ConsoleColors.RESET);
        String att_categoria = input.nextLine();

        System.out.println(ConsoleColors.BLUE_BOLD + "Informe a CILINDRADA do MOTOR do veiculo para atualizar no sistema\nSe o motor e 1,0 ; 2,0 ; etc.\nNo formato '1,0', '2,0':" + ConsoleColors.RESET);
        String att_motor = input.nextLine();

        System.out.println(ConsoleColors.BLUE_BOLD + "Informe o CÂMBIO do veiculo para atualizar no sistema(manual ou automático): " + ConsoleColors.RESET);
        String att_cambio = input.nextLine();

        
        String query = "UPDATE public.veiculos SET modelo = ?, marca = ?, preco_medio = ?, custo_med_manu = ?, km_por_l = ?, relacao_pp = ?, motorizacao = ?, torque = ?, categoria = ?, motor = ?, cambio = ? WHERE id = ?";
        try {
        	//System.out.println("preparando query");
        	db.conectBanco();
        	PreparedStatement ps = db.conection.prepareStatement(query);
            ps.setString(1, att_modelo);
            ps.setString(2, att_marca);
            ps.setInt(3, att_precoMed);
            ps.setInt(4, att_custo_med_manu);
            ps.setFloat(5, att_km_por_litro);
            ps.setFloat(6, att_relacao_pp);
            ps.setString(7, att_motorizacao);
            ps.setFloat(8, att_torque);
            ps.setString(9, att_categoria);
            ps.setString(10, att_motor);
            ps.setString(11, att_cambio);
            ps.setInt(12, id);
            ps.executeUpdate(); // executa query desejada
            System.out.println(ConsoleColors.GREEN_BOLD_BRIGHT+"Veículo atualizado com sucesso!"+ConsoleColors.RESET);
        }
	    catch (Exception e) {
	        Funcoes.msgnErro("Erro ao executar update: " + e.getMessage());
	    }
        finally {
	        db.desconectBanco();
	    }
	}
	
	public static boolean verificarDBvazio(DbContext db) {
		
		boolean v_controle = false;
		int contador_linhas = 0;
		String query = "SELECT COUNT(*) FROM public.veiculos";
		
		//System.out.println("\n ----- Verificando o banco ----- ");
		try {
			db.conectBanco();
			ResultSet resultado_consulta = db.execQuerySql(query);
			while(resultado_consulta.next()) {
				contador_linhas = resultado_consulta.getInt(1);
				//System.out.println(contador_linhas);
			}
		}
		catch (Exception e) {
			Funcoes.msgnErro("Erro ao verificar banco de dados"+ e.getMessage());
		} 
		finally {
			db.desconectBanco();
		}
		v_controle = (contador_linhas == 0);
		return v_controle;
	}
	
	// Verificar se o banco tem 2 itens ou mais
	public static boolean validarComparacao(DbContext db) {
	    
	    
	    int contador_linhas = 0;
	    String query = "SELECT COUNT(*) FROM public.veiculos";
	    
	    //System.out.println("\n ----- Verificando o banco ----- ");
	    try {
	        db.conectBanco();
	        ResultSet resultado_consulta = db.execQuerySql(query);
	        if (resultado_consulta.next()) {
	            contador_linhas = resultado_consulta.getInt(1);
	            System.out.println("Contagem de linhas: " + contador_linhas); // Adicionado para depuração
	        }
	    } catch (Exception e) {
	        Funcoes.msgnErro("Erro ao verificar banco de dados: " + e.getMessage());
	    } finally {
	        db.desconectBanco();
	    }
	    if (contador_linhas > 1) {
	    	return true;
	    }
	    else {
	    	return false;
	    }	    
	}

	//funcao de verificaçao do id inserido
	public static boolean verificarID(DbContext db, int id) throws SQLException {
		
	    boolean id_valido = false;

	    if (id == 0) {
	        Funcoes.msgnErro("Erro de indice. Não pode ser 0");
	        return false;
	    }
	    
	    String query = "SELECT * FROM veiculos WHERE id = ?";
	    try {
	        db.conectBanco();
	        PreparedStatement ps = db.conection.prepareStatement(query);
	        ps.setInt(1, id);
	        ResultSet rs = ps.executeQuery();
	        if (rs.next()) {
	            id_valido = true;
	        }
	        rs.close();
	        ps.close();
	    } catch (Exception e) {
	        Funcoes.msgnErro("Erro ao verificar ID: " + e.getMessage());
	    } finally {
	        db.desconectBanco();
	    }
	    return id_valido;
	}


	
	// listagem de todos os itens do banco
	public static void listarTudo(DbContext db) throws SQLException {
		
		int item = 1;
		
		//System.out.println(ConsoleColors.GREEN_BOLD + " -- Inicando retorno do banco... -- " + ConsoleColors.RESET);
		
		if (verificarDBvazio(db)) {
			System.out.println("Banco vazio");
			return ;
		}
		try{
			db.conectBanco();
			ResultSet resultadoConsulta = db.execQuerySql("SELECT * FROM public.veiculos");
			Funcoes.linha();
			System.out.println(ConsoleColors.BLUE_BRIGHT + "      <<<<<< Imprimindo itens do banco >>>>>>      " + ConsoleColors.RESET);
			
			while(resultadoConsulta.next()) {
				System.out.println("------------------< Item -> " + item + " >-------------------\n");
				System.out.println( ConsoleColors.BLUE_BOLD +   "ID: " + ConsoleColors.RESET + resultadoConsulta.getString("id") + "\n"
									+ ConsoleColors.BLUE_BOLD + "Modelo: " + ConsoleColors.RESET + resultadoConsulta.getString("modelo") + "\n"
									+ ConsoleColors.BLUE_BOLD + "Marca: " + ConsoleColors.RESET + resultadoConsulta.getString("marca") + "\n"
									+ ConsoleColors.BLUE_BOLD + "Preço médio: " + ConsoleColors.RESET + resultadoConsulta.getString("preco_medio") + "\n"
									+ ConsoleColors.BLUE_BOLD + "Custo médio de manutenção: " + ConsoleColors.RESET  + resultadoConsulta.getString("custo_med_manu") + "\n"
									+ ConsoleColors.BLUE_BOLD + "Kilometros por litro de comustivel: "+ ConsoleColors.RESET  + resultadoConsulta.getString("km_por_l") + "\n"
									+ ConsoleColors.BLUE_BOLD + "Relação peso-potência: "+ ConsoleColors.RESET  + resultadoConsulta.getString("relacao_pp") + "\n"
									+ ConsoleColors.BLUE_BOLD + "Motorizacao: "+ ConsoleColors.RESET  + resultadoConsulta.getString("motorizacao") + "\n"
									+ ConsoleColors.BLUE_BOLD + "Torque: "+ ConsoleColors.RESET  + resultadoConsulta.getString("torque") + "\n"
									+ ConsoleColors.BLUE_BOLD + "Tipo: "+ ConsoleColors.RESET  + resultadoConsulta.getString("categoria") + "\n"
									+ ConsoleColors.BLUE_BOLD + "Poência do motor: "+ ConsoleColors.RESET  + resultadoConsulta.getString("motor") + "\n"
									+ ConsoleColors.BLUE_BOLD + "Tipo do câmbio: "+ ConsoleColors.RESET  + resultadoConsulta.getString("cambio"));
				System.out.println("--------------------------------------------------");
				item++;
			}
			System.out.println("------------------- Finalizado -------------------\n");
			Funcoes.linha();
			}
		catch (Exception e) {
			Funcoes.msgnErro("Erro ao listar." + e.getMessage());
		} 
		finally {
			db.desconectBanco();
		}
	}
		
	
	
	// funcao de comparacao de 2 modelos disponiveis no banco
	public static void compararModelos(Scanner input, DbContext db) {
		
		if (!validarComparacao(db)) {
			System.out.println(ConsoleColors.RED_BOLD_BRIGHT + "Não e possivel comparar. Número de itens inferior a 2.");
			return;
		}
		
		boolean sucesso_cons = false;
		String[] itens = new String[2];
		String[][] listaConsulta = new String[2][12];
		
		Funcoes.linha();
		System.out.println(ConsoleColors.GREEN_BACKGROUND + "--< Comparando Modelos >--" + ConsoleColors.RESET);
		System.out.println(ConsoleColors.BLUE_BOLD_BRIGHT + "Insira os dois modelos a serem comparados: ");
		System.out.print(ConsoleColors.YELLOW + "Item 1: " + ConsoleColors.RESET);
		itens[0] = input.nextLine();
		System.out.print(ConsoleColors.YELLOW + "Item 2: " + ConsoleColors.RESET);
		itens[1] = input.nextLine();
		Funcoes.linha();
		
		try {
			db.conectBanco();
		}
		catch(Exception e) {}
		
		for (int i = 0; i<=1;i++) {
			try{
				String query = "SELECT * FROM public.veiculos WHERE modelo = '" + itens[i] + "'";
				// recebe o resultado da consulta
				ResultSet rC = db.execQuerySql(query);
				
				while(rC.next()) {
					listaConsulta[i][0] = rC.getString("id");
					listaConsulta[i][1] = rC.getString("modelo");
	                listaConsulta[i][2] = rC.getString("marca");
	                listaConsulta[i][3] = rC.getString("preco_medio");
	                listaConsulta[i][4] = rC.getString("custo_med_manu");
	                listaConsulta[i][5] = rC.getString("km_por_l");
	                listaConsulta[i][6] = rC.getString("relacao_pp");
	                listaConsulta[i][7] = rC.getString("motorizacao");
	                listaConsulta[i][8] = rC.getString("torque");
	                listaConsulta[i][9] = rC.getString("categoria");
	                listaConsulta[i][10] = rC.getString("motor");
	                listaConsulta[i][11] = rC.getString("cambio");
	                
				}
				sucesso_cons = true;
			}
			catch (Exception e) {
				Funcoes.msgnErro("Erro na conslta -> " + e.getMessage());
			}
		}
		if (sucesso_cons) {
			System.out.println(ConsoleColors.YELLOW_BOLD+    "             -- Modelo 1 --         " +ConsoleColors.PURPLE_BRIGHT+ "|"+ConsoleColors.YELLOW_BOLD+"         -- Modelo 2 --             ");
			System.out.printf(ConsoleColors.BLUE_BOLD_BRIGHT+"ID                ->"+ ConsoleColors.RESET+"%15s"+  ConsoleColors.PURPLE_BRIGHT+" | "+ ConsoleColors.RESET+"%-15s"+ConsoleColors.BLUE_BOLD_BRIGHT+"<-               ID\n"+ConsoleColors.RESET, listaConsulta[0][0], listaConsulta[1][0]);
			System.out.printf(ConsoleColors.BLUE_BOLD_BRIGHT+"Modelo            ->"+ ConsoleColors.RESET+"%15s"+  ConsoleColors.PURPLE_BRIGHT+" | "+ ConsoleColors.RESET+"%-15s"+ConsoleColors.BLUE_BOLD_BRIGHT+"<-           Modelo\n"+ConsoleColors.RESET, listaConsulta[0][1], listaConsulta[1][1]);
			System.out.printf(ConsoleColors.BLUE_BOLD_BRIGHT+"Marca             ->"+ ConsoleColors.RESET+"%15s"+  ConsoleColors.PURPLE_BRIGHT+" | "+ ConsoleColors.RESET+"%-15s"+ConsoleColors.BLUE_BOLD_BRIGHT+"<-            Marca\n"+ConsoleColors.RESET, listaConsulta[0][2], listaConsulta[1][2]);
			System.out.printf(ConsoleColors.BLUE_BOLD_BRIGHT+"Preço Medio       ->"+ ConsoleColors.RESET+"%15s"+  ConsoleColors.PURPLE_BRIGHT+" | "+ ConsoleColors.RESET+"%-15s"+ConsoleColors.BLUE_BOLD_BRIGHT+"<-      Preço Médio\n"+ConsoleColors.RESET, listaConsulta[0][3], listaConsulta[1][3]);
			System.out.printf(ConsoleColors.BLUE_BOLD_BRIGHT+"Custo Medio Manu. ->"+ ConsoleColors.RESET+"%15s"+  ConsoleColors.PURPLE_BRIGHT+" | "+ ConsoleColors.RESET+"%-15s"+ConsoleColors.BLUE_BOLD_BRIGHT+"<- Custo Medio Manu\n"+ConsoleColors.RESET, listaConsulta[0][4], listaConsulta[1][4]);
			System.out.printf(ConsoleColors.BLUE_BOLD_BRIGHT+"Consumo(km/l)     ->"+ ConsoleColors.RESET+"%15s"+  ConsoleColors.PURPLE_BRIGHT+" | "+ ConsoleColors.RESET+"%-15s"+ConsoleColors.BLUE_BOLD_BRIGHT+"<-    Consumo(km/l)\n"+ConsoleColors.RESET, listaConsulta[0][5], listaConsulta[1][5]);
			System.out.printf(ConsoleColors.BLUE_BOLD_BRIGHT+"Relação P-P       ->"+ ConsoleColors.RESET+"%15s"+  ConsoleColors.PURPLE_BRIGHT+" | "+ ConsoleColors.RESET+"%-15s"+ConsoleColors.BLUE_BOLD_BRIGHT+"<-      Relação P-P\n"+ConsoleColors.RESET, listaConsulta[0][6], listaConsulta[1][6]);
			System.out.printf(ConsoleColors.BLUE_BOLD_BRIGHT+"Motorização       ->"+ ConsoleColors.RESET+"%15s"+  ConsoleColors.PURPLE_BRIGHT+" | "+ ConsoleColors.RESET+"%-15s"+ConsoleColors.BLUE_BOLD_BRIGHT+"<-      Motorização\n"+ConsoleColors.RESET, listaConsulta[0][7], listaConsulta[1][7]);
			System.out.printf(ConsoleColors.BLUE_BOLD_BRIGHT+"Torque            ->"+ ConsoleColors.RESET+"%15s"+  ConsoleColors.PURPLE_BRIGHT+" | "+ ConsoleColors.RESET+"%-15s"+ConsoleColors.BLUE_BOLD_BRIGHT+"<-           Torque\n"+ConsoleColors.RESET, listaConsulta[0][8], listaConsulta[1][8]);
			System.out.printf(ConsoleColors.BLUE_BOLD_BRIGHT+"Categoria         ->"+ ConsoleColors.RESET+"%15s"+  ConsoleColors.PURPLE_BRIGHT+" | "+ ConsoleColors.RESET+"%-15s"+ConsoleColors.BLUE_BOLD_BRIGHT+"<-        Categoria\n"+ConsoleColors.RESET, listaConsulta[0][9], listaConsulta[1][9]);
			System.out.printf(ConsoleColors.BLUE_BOLD_BRIGHT+"Cilindrada        ->"+ ConsoleColors.RESET+"%15s"+  ConsoleColors.PURPLE_BRIGHT+" | "+ ConsoleColors.RESET+"%-15s"+ConsoleColors.BLUE_BOLD_BRIGHT+"<-       Cilindrada\n"+ConsoleColors.RESET, listaConsulta[0][10], listaConsulta[1][10]);
			System.out.printf(ConsoleColors.BLUE_BOLD_BRIGHT+"Câmbio            ->"+ ConsoleColors.RESET+"%15s"+  ConsoleColors.PURPLE_BRIGHT+" | "+ ConsoleColors.RESET+"%-15s"+ConsoleColors.BLUE_BOLD_BRIGHT+"<-           Câmbio\n"+ConsoleColors.RESET, listaConsulta[0][11], listaConsulta[1][11]);
		}
		
		db.desconectBanco();
		}
}
